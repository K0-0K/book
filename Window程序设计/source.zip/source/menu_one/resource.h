//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by menu_one.rc
//
#define IDR_MYMENU                      101
#define IDI_MYICON                      102
#define ID_FILE_EXIT                    40001
#define ID_STUFF_GO                     40002
#define ID_STUFF_GOSOMEWHEREELSE        40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
