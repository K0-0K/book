var BLOG_AD = {
	"scroll": {
		'ad': 1,
		'rtt': 1,
		'adnum': 2,
		'ads': {
			'0': {
				'startdate': '2012-4-11 9:00:00',
				'enddate': '2012-4-12 9:30:00',
				'warp': 1,
				'ads': {
					'0': {
						"type": "pic",
						"pos": "scroll",
						"width": 140,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=386326,446772,452072&cid=0,0,0&sid=450188&advid=6876&camid=69694&show=ignore&url=http://all.vic.sina.com.cn/HKDL/landing2.php?utm_source=Sina&utm_channel=TA2%E5%8D%9A%E5%AE%A2%E6%8E%A8%E8%8D%90%E5%8D%9A%E6%96%87%E9%A1%B5&utm_medium=%E5%8D%9A%E5%AE%A2%E5%8D%9A%E6%96%87%E6%8C%89%E9%92%AE",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d2.sina.com.cn/201204/10/407758_TA2-140150.jpg",
						"content": ''
					},
					'1': {
						"type": "pic",
						"pos": "scroll",
						"width": 25,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=386326,446772,452072&cid=0,0,0&sid=450188&advid=6876&camid=69694&show=ignore&url=http://all.vic.sina.com.cn/HKDL/landing2.php?utm_source=Sina&utm_channel=TA2%E5%8D%9A%E5%AE%A2%E6%8E%A8%E8%8D%90%E5%8D%9A%E6%96%87%E9%A1%B5&utm_medium=%E5%8D%9A%E5%AE%A2%E5%8D%9A%E6%96%87%E6%8C%89%E9%92%AE",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d3.sina.com.cn/201204/10/407759_25x150.jpg",
						"content": ''
					}
				}
			},
			'1': {
				'startdate': '2012-4-19 9:00:00',
				'enddate': '2012-4-20 9:00:00',
				'warp': 1,
				'ads': {
					'0': {
						"type": "pic",
						"pos": "scroll",
						"width": 140,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=388958,449490,454789&cid=0,0,0&sid=452965&advid=7610&camid=71146&show=ignore&url=http://ad-apac.doubleclick.net/click;h=v2|3F2A|0|0|%2a|b;255923038;0-0;0;79591893;31-1|1;47629893|47645366|1;;%3fhttp://detail.tmall.com/item.htm?id=16620252164&scm=1004.2.1.4?utm_source=Sina&utm_medium=Day&utm_term=v1&utm_content=PFA03&utm_campaign=UL_Pond's FC Angie",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d2.sina.com.cn/201204/18/410775_ponds_140x150.jpg",
						"content": ''
					},
					'1': {
						"type": "pic",
						"pos": "scroll",
						"width": 25,
						"height": 150,
						"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=388958,449490,454789&cid=0,0,0&sid=452965&advid=7610&camid=71146&show=ignore&url=http://ad-apac.doubleclick.net/click;h=v2|3F2A|0|0|%2a|b;255923038;0-0;0;79591893;31-1|1;47629893|47645366|1;;%3fhttp://detail.tmall.com/item.htm?id=16620252164&scm=1004.2.1.4?utm_source=Sina&utm_medium=Day&utm_term=v1&utm_content=PFA03&utm_campaign=UL_Pond's FC Angie",
						"status": {
							"adstart": "",
							"adend": "",
							"adclose": ""
						},
						"ref": "http://d3.sina.com.cn/201204/18/410777_25x150ponds.jpg",
						"content": ''
					}
				}
			}
		}
	},
	"comment": {
		'ad': 1,
		'adnum': 3,
		'ads': {
			'0': {
				"type": "txt",
				"pos": "comment",
				"link": '[��Ѷ]<a href="http://mall.sina.com.cn/"  target="_blank">���Ϲ��������̳�</a>',
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				}
			},
			'1': {
				"type": "txt",
				"pos": "comment",
				"link": '[��Ѷ]<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=277830,334360,339653&cid=0,0,0&sid=334533&advid=7567&camid=52451&show=ignore&url=http://all.vic.sina.com.cn/2011citicgongyi/index.php"  target="_blank">����ǩ�������룬�����ɽ�</a>',
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				}
			},
			'2': {
				"type": "txt",
				"pos": "comment",
				"link": '[��Ѷ]<a href="http://sina.allyes.com/main/adfclick?db=sina&bid=204720,299859,305135&cid=0,0,0&sid=298939&advid=358&camid=37389&show=ignore&url=http://blog.sina.com.cn/s/blog_705463570100phtd.html?tj=1"  target="_blank">��߲��������·���</a>',
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				}
			}
		}
	},
	"video": {
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads': {
			'0': {
				"type": "swf",
				"pos": "video",
				"startdate": "2012-04-19 9:00:00",
				"enddate": "2012-04-20 9:00:00",
				"width": 260,
				"height": 190,
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d2.sina.com.cn/201204/05/406453_260x190-jj.swf", <!--$$ jiayu/2012-4-19 ~ 2012-4-19/B $-->
				"content": ''
			},
			'1': {
				"type": "swf",
				"pos": "video",
				"startdate": "2012-04-19 9:00:00",
				"enddate": "2012-04-21 9:00:00",
				"width": 260,
				"height": 190,
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d4.sina.com.cn/201204/18/411081_blog260-190-a.swf",
				"content": ''
			}
		}
	},
	"leftsx": {
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads': {
			'0': {
				"type": "pic",
				"pos": "leftsx",
				'startdate': '2012-2-10 9:30',
				'enddate': '2012-2-15 0:00',
				"width": 200,
				"height": 200,
				"click": "http://sina.allyes.com/main/adfclick?db=sina&bid=204720,413238,418552&cid=0,0,0&sid=416142&advid=358&camid=37389&show=ignore&url=http://qing.weibo.com/tag/%E6%83%85%E4%BA%BA%E8%8A%82",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d3.sina.com.cn/litong/kuaijieweibo/yafeng/zcsx200_200.jpg",
				"ref2": "",
				"content": "",
				"isusewb": "false",
				"addata": {
					clickCode: "http://sina.allyes.com/main/adfclick?db=sina&bid=247819,404560,409873&cid=0,0,0&sid=407235&advid=358&camid=46514&show=ignore",
					appkey: "2034545597",
					ralateUid: "1717871843",
					title: "ɳĮ�籩��Ϯ��# Ӣ�׸�����Ʒ紵���ִ�������Ů�����壡DUDUŮħͷ��˽�ܿռ�ϵ��ʱ��ţƤ���ð���ְ��Ů�Աر�����",
					pic: "",
					url: ""
				},
				'txtarr': [{
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}]
			},
			'1': {
				"type": "swf",
				"pos": "leftsx",
				'startdate': '2011-11-01 9:30',
				'enddate': '2011-11-13 9:30',
				"width": 200,
				"height": 200,
				"click": "http://video.sina.com.cn/p/news/s/v/2011-11-15/111661560991.html",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d4.sina.com.cn/201112/19/382962_190200blog_an_1220.swf",
				"ref2": "http://d4.sina.com.cn/litong/kuaijieweibo/yafeng/ccqc300.jpg",
				"content": "",
				"isusewb": "true",
				"addata": {
					clickCode: "http://sina.allyes.com/main/adfclick?db=sina&bid=247819,404560,409873&cid=0,0,0&sid=407235&advid=358&camid=46514&show=ignore",
					appkey: "2034545597",
					ralateUid: "1717871843",
					title: "ɳĮ�籩��Ϯ��# Ӣ�׸�����Ʒ紵���ִ�������Ů�����壡DUDUŮħͷ��˽�ܿռ�ϵ��ʱ��ţƤ���ð���ְ��Ů�Աر�����",
					pic: "",
					url: ""
				},
				'txtarr': [{
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}, {
					"href": "",
					"content": ""
				}]
			}
		}
	},
	"topbanner": {
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads': {
			'0': {
				"type": "swf",
				"pos": "topbanner",
				"width": 950,
				"height": 30,
				'startdate': '2011-11-15 09:00:00',
				'enddate': '2011-11-17 09:00:00',
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d5.sina.com.cn/201111/14/370454_950x30-blog-acer.swf",
				"content": ''
			},
			'1': {
				"type": "swf",
				"pos": "topbanner",
				"width": 950,
				"height": 30,
				'startdate': '2011-11-21 09:00:00',
				'enddate': '2011-11-24 09:00:00',
				"click": "",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "http://d1.sina.com.cn/201111/19/372476_el_950x30_20K.SWF",
				"content": ''
			}
		}
	},
	"jumpin": {
		'ad': 0,
		'adnum': 1,
		'ads': {
			'0': {
				"type": "swf",
				"pos": "jumpin",
				"width": 240,
				"height": 60,
				'startdate': '2011-4-23',
				'enddate': '2011-4-29',
				"click": "http://www.sina.com.cn/",
				"status": {
					"adstart": "",
					"adend": "",
					"adclose": ""
				},
				"ref": "",
				"content": ''
			}
		}
	},
	setContent: function(c) {
		switch (c.type) {
		case "swf":
			return '<object id="playerobj" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9" classid=clsid:d27cdb6e-ae6d-11cf-96b8-444553540000 width="' + c.width + '" height="' + c.height + '" type="application/x-shockwave-flash"><param name="movie" value="' + c.ref + '"><param name="wmode" value="transparent"><param name="quality" value="high"><param name="allowscriptaccess" value="always"><param name="scale" value="exactfit"><embed name="playerobj" width="' + c.width + '" height="' + c.height + '" src="' + c.ref + '"  quality="high" allowScriptAccess="always" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent" scale="exactfit"></embed></object>';
			break;
		case "pic":
			return '<a href="' + c.click + '" target="_blank"><img src="' + c.ref + '" width=' + c.width + "px height=" + c.height + 'px" /></a>';
			break;
		case "flv":
			return this.playerize(c.width, c.height, c.ref, c.click, c.ref2);
			break;
		case "txt":
			var data = c.txtarr;
			var str = "";
			for (var i = 0; i < data.length; i++) {
				str = str + '<li><p><span class="SG_dot"></span><a href="' + data[i]["href"] + '" target="_blank">' + data[i]["content"] + '</a></p></li>';
			}
			str = '<ul class="onlylist cmtA_arti">' + str + '</ul>';
			return str;
			break;
		case "iframe":
			return '<iframe width="' + c.width + '" height="' + c.height + '" frameborder="0" scrolling="no" src="' + (c.ref) + '"></iframe>';
			break;
		}
	},
	playerize: function(width, height, ref, clickfun, ref2) {
		return '<iframe width="' + width + '" height="' + height + '" frameborder="0" scrolling="no" src="http://pfp.sina.com.cn/blog/blogplayer.html?flvurl=' + encodeURIComponent(ref) + '&linkurl=' + encodeURIComponent(clickfun) + '&width=' + width + '&height=' + height + '&pic=' + ref2 + '"></iframe>';
	}
};
(function() {
	BLOG_AD.leftsx.ads["0"].content = BLOG_AD.setContent(BLOG_AD.leftsx.ads["0"]);
	BLOG_AD.leftsx.ads["0"].type = "mix";
	BLOG_AD.leftsx.ads["1"].content = BLOG_AD.setContent(BLOG_AD.leftsx.ads["1"]);
	BLOG_AD.leftsx.ads["1"].type = "mix";
})();