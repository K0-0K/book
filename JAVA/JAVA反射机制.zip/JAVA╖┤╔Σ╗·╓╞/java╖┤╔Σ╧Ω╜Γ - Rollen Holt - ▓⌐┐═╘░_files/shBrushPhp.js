﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>404错误：资源不存在</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style style="text/css">
	body{font-size:14px;font-family: verdana,Arial,Helvetica;line-height:150%;}
	a:link,a:visited,a:active{color: #075DB3;text-decoration: underline;}
    a:hover	{color: red;}
	body{line-height:200%;}
	ul{margin-top:5px;margin-left:0px;padding-left:0px;}
	li{display:inline;padding-right:20px;}
	</style>
</head>
<body>
<div align="center">
<div id="main" style="width:800px;text-align:left">
<div><a href="http://www.cnblogs.com/"><img src="http://www.cnblogs.com/images/logo150.gif" alt="博客园logo" style="border:0px"/></a></div>
<div id="logo" style="text-align:center"><a href="http://www.cnblogs.com/cmt/archive/2010/06/08/1753881.html"><img src="http://static.cnblogs.com/images/t_shirt_404.jpg" alt="404" style="border:0px"/></a></div>
<div id="tips" style="margin-top:10px;margin-bottom:10px;">
<span style="color:red;"><b>抱歉！您访问的资源不存在!</b></span><br/>
给您带来麻烦了！确认您输入的地址是否正确，如果问题持续存在，请发邮件至contact&#64;cnblogs.com与网站管理员联系。
</div>
<div id="sitelink">
<b style="color:#555;">网站导航：</b>
<ul>
<li><a href="http://www.cnblogs.com">博客园首页</a></li>
<li><a href="http://news.cnblogs.com/">看看IT新闻</a></li>
<li><a href="http://space.cnblogs.com/q/">我要提问</a></li>
<li><a href="http://job.cnblogs.com">招聘与求职</a></li>
<li><a href="http://kb.cnblogs.com">知识库</a></li>
<li><a href="http://passport.cnblogs.com/register.aspx">注册会员</a></li>
</div>
</div>
<div style="width:800px;margin-top:20px;color:gray;border-top:1px solid #EEE;text-align:right;font-size:12px;">
<a href="/AboutUS.aspx">关于博客园</a> | <a href="/ContactUs.aspx">联系我们</a>  &nbsp;技术改变世界
</div>
</div>
</div>
</body>
</html>