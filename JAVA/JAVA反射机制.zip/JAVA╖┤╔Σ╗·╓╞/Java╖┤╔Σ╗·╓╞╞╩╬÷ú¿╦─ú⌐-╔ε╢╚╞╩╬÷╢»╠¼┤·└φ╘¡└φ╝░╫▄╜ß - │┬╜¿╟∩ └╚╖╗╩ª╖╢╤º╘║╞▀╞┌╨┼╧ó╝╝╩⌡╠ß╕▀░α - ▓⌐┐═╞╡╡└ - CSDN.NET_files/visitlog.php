i ffa4f92f7b4bc4a0f406f8d89ec59b6e
Query failed : Can't open file: 'visitlog.MYI' (errno: 145)