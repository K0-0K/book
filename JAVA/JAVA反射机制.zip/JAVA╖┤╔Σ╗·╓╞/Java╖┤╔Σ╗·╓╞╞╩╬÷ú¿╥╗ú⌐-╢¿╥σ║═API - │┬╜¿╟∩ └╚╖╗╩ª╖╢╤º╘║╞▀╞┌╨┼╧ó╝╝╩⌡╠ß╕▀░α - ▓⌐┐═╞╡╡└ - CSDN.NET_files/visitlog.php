i fafedaeefb499289845a66ef792f72c1
Query failed : Can't open file: 'visitlog.MYI' (errno: 145)