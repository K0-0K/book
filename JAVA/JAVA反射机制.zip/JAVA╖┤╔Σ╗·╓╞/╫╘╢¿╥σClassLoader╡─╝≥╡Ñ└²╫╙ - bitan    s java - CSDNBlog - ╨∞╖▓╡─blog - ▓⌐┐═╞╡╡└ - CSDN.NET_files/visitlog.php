i e4435f00f755c4a5f91c1b9de1827883
Query failed : Can't open file: 'visitlog.MYI' (errno: 145)