i 7e08effbc387b6441da8acef8fa02afd
Query failed : Can't open file: 'visitlog.MYI' (errno: 145)