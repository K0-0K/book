i 7545f7fabd831d95dddcc8d5e59f4a08
Query failed : Can't open file: 'visitlog.MYI' (errno: 145)