public class StaticDemo {
    public static void sayHello() {
        System.out.println("������");
    }

    public static void main(String[] args) {
        sayHello();
    }
}