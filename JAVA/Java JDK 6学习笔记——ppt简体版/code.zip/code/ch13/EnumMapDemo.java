package onlyfun.caterpillar;
 
import java.util.*;
 
enum Action {TURN_LEFT, TURN_RIGHT, SHOOT}
 
public class EnumMapDemo {
    public static void main(String[] args) {
        Map<Action, String> map = 
          new EnumMap<Action, String>(Action.class);
        
        map.put(Action.TURN_LEFT, "����ת");
        map.put(Action.TURN_RIGHT, "����ת");
        map.put(Action.SHOOT, "���");
        
        for(Action action : Action.values( ) ) {
	// ��Actionö��Ϊ��ȡ��ֵ
            System.out.println(map.get(action));
        }
    }
}