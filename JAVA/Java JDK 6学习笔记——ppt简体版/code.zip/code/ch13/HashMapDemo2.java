package onlyfun.caterpillar;
 
import java.util.*;
 
public class HashMapDemo2 {
    public static void main(String[] args) {
        Map<String, String> map = 
                  new HashMap<String, String>();
 
        map.put("justin", "justin ��ѶϢ");
        map.put("momor", "momor ��ѶϢ");
        map.put("caterpillar", "caterpillar ��ѶϢ");
        
        Collection collection = map.values();
        Iterator iterator = collection.iterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }
        System.out.println();

        // ��ʵ��Ҳ����ʹ����ǿ�� for ѭ��
        for(String value : map.values()) {
            System.out.println(value);
        }
    }
}