public class AnonymousClassDemo { 
    public static void main(String[] args) { 
        Object obj = 
            new Object() { 
                public String toString() { // ���¶���toString()
                    return "���������"; 
                } 
            }; 

        System.out.println(obj); 
    } 
}