import onlyfun.caterpillar.*;

public class Point2DDemo3 { 
    public static void main(String[] args) { 
        Point2D p1 = new Point2D(10, 20);
 
        System.out.printf("p1: (x, y) = (%d, %d)%n",
            p1.getX(), p1.getY()); 
    } 
}