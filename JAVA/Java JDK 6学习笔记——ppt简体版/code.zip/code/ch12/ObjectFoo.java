public class ObjectFoo {
    private Object foo;
 
    public void setFoo(Object foo) {
        this.foo = foo;
    }
 
    public Object getFoo() {
        return foo;
    }
}