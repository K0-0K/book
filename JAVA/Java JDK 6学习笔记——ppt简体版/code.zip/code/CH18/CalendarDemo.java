package onlyfun.caterpillar;

import java.util.Calendar;

public class CalendarDemo {
    public static void main(String[] args) {
        Calendar rightNow = Calendar.getInstance();
       System.out.println("����ʱ���ǣ�");
        System.out.println("��Ԫ��" +
                   rightNow.get(Calendar.YEAR));
        System.out.println("�£�" + 
                   getChineseMonth(rightNow));
        System.out.println("�գ�" + 
                   rightNow.get(Calendar.DAY_OF_MONTH));
        System.out.println("���ڣ�" + 
                   getChineseDayOfWeek(rightNow));

    }
    
    public static String getChineseMonth(Calendar rightNow) {
        String chineseMonth = null;
        
      switch(rightNow.get(Calendar.MONTH)) {
            case Calendar.JANUARY:
                chineseMonth = "һ";
                break;
            case Calendar.FEBRUARY:
                chineseMonth = "��";
                break;
            case Calendar.MARCH:
                chineseMonth = "��";
                break;
            case Calendar.APRIL:
                chineseMonth = "��";
                break;
            case Calendar.MAY:
                chineseMonth = "��";
                break;
            case Calendar.JUNE:
                chineseMonth = "��";
                break;
            case Calendar.JULY:
                chineseMonth = "��";
                break;
            case Calendar.AUGUST:
                chineseMonth = "��";
                break;
            case Calendar.SEPTEMBER:
                chineseMonth = "��";
                break;
            case Calendar.OCTOBER:
                chineseMonth = "ʮ";
                break;
            case Calendar.NOVEMBER:
                chineseMonth = "ʮһ";
                break;
            case Calendar.DECEMBER:
                chineseMonth = "ʮ��";
                break;                
        }
        
        return chineseMonth;
    }
    
    public static String getChineseDayOfWeek(
                                 Calendar rightNow) {
        String chineseDayOfWeek = null;
        
        switch(rightNow.get(Calendar.DAY_OF_WEEK)) {
            case Calendar.SUNDAY:
                chineseDayOfWeek = "��";
                break;
            case Calendar.MONDAY:
                chineseDayOfWeek = "һ";
                break;
            case Calendar.TUESDAY:
                chineseDayOfWeek = "��";
                break;
            case Calendar.WEDNESDAY:
                chineseDayOfWeek = "��";
                break;
            case Calendar.THURSDAY:
                chineseDayOfWeek = "��";
                break;
            case Calendar.FRIDAY:
                chineseDayOfWeek = "��";
                break;
            case Calendar.SATURDAY:
                chineseDayOfWeek = "��";
                break;           
        }
        
        return chineseDayOfWeek;

    }
}