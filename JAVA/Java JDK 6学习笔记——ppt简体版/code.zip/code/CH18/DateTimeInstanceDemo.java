package onlyfun.caterpillar;
 
import java.text.DateFormat;
import java.util.Date;

public class DateTimeInstanceDemo {
    public static void main(String[] args) {
        // ȡ��Ŀǰʱ��
        Date date = new Date(); 

        // �����Ϣ��ʽ
        DateFormat shortFormat = 
            DateFormat.getDateTimeInstance( 
                DateFormat.SHORT, DateFormat.SHORT); 
        // �е���Ϣ��ʽ
        DateFormat mediumFormat = 
            DateFormat.getDateTimeInstance( 
                DateFormat.MEDIUM, DateFormat.MEDIUM); 
        // ����Ϣ��ʽ
        DateFormat longFormat = 
            DateFormat.getDateTimeInstance( 
                DateFormat.LONG, DateFormat.LONG); 
        // ��ϸ��Ϣ��ʽ
        DateFormat fullFormat = 
            DateFormat.getDateTimeInstance( 
                DateFormat.FULL, DateFormat.FULL); 

        System.out.println("�����Ϣ��ʽ��" + 
                      shortFormat.format(date)); 
        System.out.println("�е���Ϣ��ʽ��" + 
                      mediumFormat.format(date)); 
        System.out.println("����Ϣ��ʽ��" + 
                      longFormat.format(date)); 
        System.out.println("��ϸ��Ϣ��ʽ��" + 
                      fullFormat.format(date)); 

    }
}