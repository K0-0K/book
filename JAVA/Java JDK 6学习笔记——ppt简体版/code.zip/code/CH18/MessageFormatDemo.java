package onlyfun.caterpillar;

import java.util.ResourceBundle;
import java.text.MessageFormat;

public class MessageFormatDemo {
    public static void main(String[] args) {
        try {
            // ��messages.properties
            ResourceBundle resource = 
                  ResourceBundle.getBundle("messages2");

            String message = resource.getString(
                  "onlyfun.caterpillar.greeting");
            Object[] params = 
                new Object[] {args[0], args[1]};
            MessageFormat formatter = 
                 new MessageFormat(message);

            // ��ʾ��ʽ�������Ϣ
            System.out.println(formatter.format(params));
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("û��ָ������");

        }
    }
}