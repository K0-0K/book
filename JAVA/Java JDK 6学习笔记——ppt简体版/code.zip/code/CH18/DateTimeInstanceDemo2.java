package onlyfun.caterpillar;
 
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class DateTimeInstanceDemo2 {
    public static void main(String[] args) {
        // ȡ��Ŀǰʱ��
        Date date = new Date(); 

        // en: Ӣ��ϵ US: ����
        Locale locale = new Locale("en", "US");

        // �����Ϣ��ʽ
        DateFormat shortFormat = 
           DateFormat.getDateTimeInstance( 
              DateFormat.SHORT, DateFormat.SHORT, locale); 
        // �е���Ϣ��ʽ
        DateFormat mediumFormat = 
           DateFormat.getDateTimeInstance( 
              DateFormat.MEDIUM, DateFormat.MEDIUM, locale); 
        // ����Ϣ��ʽ
        DateFormat longFormat = 
           DateFormat.getDateTimeInstance( 
              DateFormat.LONG, DateFormat.LONG, locale); 
        // ��ϸ��Ϣ��ʽ

        DateFormat fullFormat = 
           DateFormat.getDateTimeInstance( 
                DateFormat.FULL, DateFormat.FULL, locale); 

        System.out.println("short format: " + 
                      shortFormat.format(date)); 
        System.out.println("media format: " + 
                      mediumFormat.format(date)); 
        System.out.println("long format: " + 
                      longFormat.format(date)); 
        System.out.println("full format: " + 
                      fullFormat.format(date)); 
    }
}