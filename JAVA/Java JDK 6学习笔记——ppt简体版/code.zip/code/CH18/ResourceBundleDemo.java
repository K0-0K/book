package onlyfun.caterpillar;

import java.util.ResourceBundle;

public class ResourceBundleDemo {
    public static void main(String[] args) {
        // ��messages.properties
        ResourceBundle resource = 
                  ResourceBundle.getBundle("messages");
        // ȡ�ö�Ӧ��Ϣ

        System.out.print(resource.getString(
                      "onlyfun.caterpillar.welcome") + "!");
        System.out.println(resource.getString(
                      "onlyfun.caterpillar.name") + "!");
    }
}