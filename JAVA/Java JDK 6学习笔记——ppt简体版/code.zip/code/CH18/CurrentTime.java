package onlyfun.caterpillar;

public class CurrentTime {
    public static void main(String[] args) {
        System.out.println("����ʱ��" 
               + System.currentTimeMillis());
    }
}