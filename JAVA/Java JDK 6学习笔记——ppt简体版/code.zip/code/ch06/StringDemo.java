public class StringDemo { 
    public static void main(String[] args) { 
        String text = "hello"; 
 
        System.out.println("�ַ�������:" + text); 
        System.out.println("�ַ�������:" + text.length()); 
        System.out.println("����hello?" + 
                                 text.equals("hello")); 
        System.out.println("תΪ��д:" + 
                                 text.toUpperCase()); 
        System.out.println("תΪСд:" + 
                                 text.toLowerCase()); 
    } 
} 