public class CharAtString { 
    public static void main(String[] args) { 
        String text = "One's left brain has nothing right.\n" 
                 + "One's right brain has nothing left.\n"; 
 
        System.out.println("�ַ�������: "); 
        for(int i = 0; i < text.length(); i++) 
            System.out.print(text.charAt(i)); 

        System.out.println("\n��һ��left: " + 
                              text.indexOf("left")); 
        System.out.println("���һ��left: " + 
                              text.lastIndexOf("left")); 
 
        char[] charArr = text.toCharArray(); 
        System.out.println("\n�ַ�Array����:"); 
        for(int i = 0; i < charArr.length; i++) 
            System.out.print(charArr[i]); 
    } 
}