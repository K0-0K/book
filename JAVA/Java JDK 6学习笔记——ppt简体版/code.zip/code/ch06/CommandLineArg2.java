public class CommandLineArg2 { 
    public static void main(String[] args) { 
        System.out.print("������Ա���: "); 
        for(String arg : args)
            System.out.print(arg + " "); 
        System.out.println(); 
    } 
}