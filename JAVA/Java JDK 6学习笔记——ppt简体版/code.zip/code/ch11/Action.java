public enum Action {
    TURN_LEFT, 
    TURN_RIGHT, 
    SHOOT
}