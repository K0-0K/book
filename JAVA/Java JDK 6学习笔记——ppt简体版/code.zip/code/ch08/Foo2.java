public class Foo2 { 
    private String name; 

    public Foo2(String name) { 
        this.name = name; 
    }

    public void showName() { 
        System.out.println("foo2 �W�١G" + name); 
    } 
}