public interface IRequest {
     public void execute();
}