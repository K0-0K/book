public class Table implements Cloneable {// Ҫ����Cloneable
    private Point center;

    public void setCenter(Point center) {
        this.center = center;
    }
    public Point getCenter() {
        return center;
    }

    public Object clone () 
                     throws CloneNotSupportedException {
        // ���ø����clone()������
        Table table = (Table) super.clone();

        if(this.center != null) {
            // ����Point���͵����ݳ�Ա
            table.center = (Point) center.clone(); 
        }
        
        return table; 
    }
}