package onlyfun.caterpillar;

public @interface Debug {}