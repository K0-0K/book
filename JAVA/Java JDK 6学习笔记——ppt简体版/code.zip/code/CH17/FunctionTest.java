 
package onlyfun.caterpillar;

public @interface FunctionTest {
     String[] value();
}