package onlyfun.caterpillar;

public @interface UnitTest {
     String value();
}