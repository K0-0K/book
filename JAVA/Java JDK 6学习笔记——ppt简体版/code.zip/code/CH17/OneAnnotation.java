package onlyfun.caterpillar;

public @interface OneAnnotation {}