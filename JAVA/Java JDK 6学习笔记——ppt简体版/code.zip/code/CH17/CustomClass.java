package onlyfun.caterpillar;

public class CustomClass {
    @Override
    public String ToString() {
        return "customObject";
    }
}