package onlyfun.caterpillar;

public class SomethingDemo {
    public static void main(String[] args) {
        Something some = new Something();
        // ���ñ�@Deprecated��ʾ�ķ���
        some.getSomething();
    }
}