public class ShiftOperator { 
    public static void main(String[] args) { 
        int number = 1; 

        System.out.println( "2��0��:" + number); 

        number = number << 1; 
        System.out.println("2��1��: " +  number); 

        number = number << 1; 
        System.out.println("2��2��: " + number); 

        number = number << 1; 
        System.out.println("2��3��: " + number); 
    } 
} 