public class DataRange { 
    public static void main(String[] args) { 
        System.out.printf("short \t��ֵ��Χ��%d ~ %d\n", 
                             Short.MAX_VALUE, Short.MIN_VALUE); 
        System.out.printf("int \t��ֵ��Χ��%d ~ %d\n", 
                             Integer.MAX_VALUE, Integer.MIN_VALUE); 
        System.out.printf("long \t��ֵ��Χ��%d ~ %d\n",
                             Long.MAX_VALUE, Long.MIN_VALUE); 
        System.out.printf("byte \t��ֵ��Χ��%d ~ %d\n", 
                             Byte.MAX_VALUE, Byte.MIN_VALUE); 
        System.out.printf("float \t��ֵ��Χ��%e ~ %e\n", 
                             Float.MAX_VALUE, Float.MIN_VALUE); 
        System.out.printf("double \t��ֵ��Χ��%e ~ %e\n", 
                             Double.MAX_VALUE, Double.MIN_VALUE); 
    } 
}