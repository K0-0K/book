public class VariableDemo { 
    public static void main(String[] args) { 
        int ageOfStudent = 5;
        double scoreOfStudent = 80.0; 
        char levelOfStudent = 'B'; 

        System.out.println("�꼶\t �÷�\t �ȼ�"); 
        System.out.printf("%4d\t %4.1f\t %4c", 
            ageOfStudent, scoreOfStudent, levelOfStudent); 
    } 
}