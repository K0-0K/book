public class IncrementDecrement3 {
    public static void main(String[] args) {
        int i = 0; 
        int number = 0; 

        number = i++;    //�൱��number = i; i = i + 1; 
        System.out.println(number); 
        number = i--;     //�൱��number = i; i = i - 1; 
        System.out.println(number); 
    }
}