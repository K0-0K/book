public class IncrementDecrement2 {
    public static void main(String[] args) {
        int i = 0; 
        int number = 0; 

        number = ++i;   // �൱��i = i + 1; number = i; 
        System.out.println(number); 
        number = --i;    // �൱��i = i - 1; number = i; 
        System.out.println(number); 
    }
}