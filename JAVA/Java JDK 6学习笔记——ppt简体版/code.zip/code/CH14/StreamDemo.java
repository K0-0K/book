package onlyfun.caterpillar;
 
import java.io.*;
 
public class StreamDemo { 
    public static void main(String[] args) { 
        try { 
            System.out.print("�����ַ�:"); 
            System.out.println("�����ַ�ʮ���Ʊ�ʾ: " + 
                                    System.in.read()); 
        } 
        catch(IOException e) { 
            e.printStackTrace(); 
        } 
    } 
}