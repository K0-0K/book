 package onlyfun.caterpillar;
 
 import java.io.*;
 
 public class StreamWriterDemo {
    public static void main(String[] args) {
        try {
            // ���������ġ��ĸ��ֵ� GB2312 ����
            byte[] sim = {(byte)0xbc, (byte)0xf2, 
                          (byte)0xcc, (byte)0xe5,
                          (byte)0xd6, (byte)0xd0,
                          (byte)0xce, (byte)0xc4};
           // ������Ϊ����Դ
            ByteArrayInputStream byteArrayInputStream = 
                            new ByteArrayInputStream(sim);
            InputStreamReader inputStreamReader = 
                new InputStreamReader( 
                  byteArrayInputStream, "GB2312"); 

             // PrintWriter������Writerʵ����Ϊ����
            PrintWriter printWriter = 
               new PrintWriter(
                 new OutputStreamWriter(
                      new FileOutputStream(args[0]), "GB2312")); 

            int in = 0; 

            printWriter.print("PrintWriter: ");
            // д����������
            while((in = inputStreamReader.read()) != -1)  { 
                printWriter.print((char)in); 
            }
            printWriter.println();

            printWriter.close();
            byteArrayInputStream.reset();

            // PrintStream ����OutputStreamʵ����Ϊ����
            PrintStream printStream = 
                new PrintStream(new FileOutputStream(args[0], true), 
                                true, "GB2312");
 
            printStream.print("PrintStream: ");
          // д����������
            while((in = inputStreamReader.read()) != -1)  { 
                printStream.print((char)in); 
            }
            printStream.println();

            inputStreamReader.close();
            printStream.close();
        } 
        catch(ArrayIndexOutOfBoundsException e) { 
            System.out.println("û��ָ���ļ�");
        } 
        catch(IOException e) { 
            e.printStackTrace(); 
        } 
    }
 }