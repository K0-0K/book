package onlyfun.caterpillar;

import java.util.*;
import java.io.*;

public class SequenceStreamDemo {
    public static void main(String[] args) {
        try { 
              // args[0]: ָ���ָs�������ӣ�c��
            switch (args[0].charAt(1)) {
                case 's':
                    // args[1]: ÿ���ָ��ļ��Ĵ�С
                    int size = Integer.parseInt(args[1]);
                    // args[2]: ָ��Ҫ���ָ���ļ����Ƥp
                    seperate(args[2], size); 
                    break;
                case 'c':
                    // args[1]: ָ��Ҫ����ϵ��ļ�����
                    int number = Integer.parseInt(args[1]);
                    // args[2]: ��Ϻ���ļ�����
                    concatenate(args[2], number); 
                    break;
            }
        } 
        catch(ArrayIndexOutOfBoundsException e) { 
            System.out.println(
                "Using: java UseSequenceStream [-s/-c]" + 
                " (size/number) filename"); 
            System.out.println("-s: �ָ��ļ�\n-c: ����ļ�"); 
        } 
        catch(IOException e) { 
            e.printStackTrace(); 
        } 
    }

     // �ָ��ļ�
    public static void seperate(String filename, int size) 
                                    throws IOException { 
        FileInputStream fileInputStream = 
            new FileInputStream(new File(filename)); 
        BufferedInputStream bufInputStream = 
            new BufferedInputStream(fileInputStream); 

        byte[] data = new byte[1]; 
        int count = 0;  
        // ��ԭ�ļ���С��ָ���ָ�Ĵ�С
        // ����Ҫ�ָ�Ϊ�����ļ� �� 
        if(fileInputStream.available() % size == 0) 
            count = fileInputStream.available() / size; 
        else 
            count = fileInputStream.available() / size + 1; 
 
         // ��ʼ���зָ�
        for(int i = 0; i < count; i++) { 
            int num = 0; 
             // �ָ���ļ����ϵ�������
            File file = new File(filename + "_" + (i + 1));
            BufferedOutputStream bufOutputStream = 
                new BufferedOutputStream( 
                       new FileOutputStream(file)); 
 
            while(bufInputStream.read(data) != -1) { 
                bufOutputStream.write(data); 
                num++; 
                if(num == size) { // �ָ��һ���ļ�
                    bufOutputStream.flush(); 
                    bufOutputStream.close(); 
                    break; 
                } 
            } 
 
            if(num < size) { 
                bufOutputStream.flush(); 
                bufOutputStream.close(); 
            } 
        } 
 
        System.out.println("�ָ�Ϊ" + count + "���ļ�"); 
    } 

    // �����ļ�
    public static void concatenate(String filename, 
                          int number) throws IOException {
        // �ռ��ļ��õ�List
        List<InputStream> list = 
                new ArrayList<InputStream>();
        
        for(int i = 0; i < number; i++) {
            // �ļ�������Ϊ���߼��ϱ��
            File file = new File(filename + "_" + (i+1));
            list.add(i, new FileInputStream(file));
        }
        
        final Iterator<InputStream> iterator = list.iterator();
        
        // SequenceInputStream ��Ҫһ��Enumeration����������
        Enumeration<InputStream> enumation = 
            new Enumeration<InputStream>() {
                public boolean hasMoreElements() {
                    return iterator.hasNext();
                }

                public InputStream nextElement() {
                    return iterator.next();
                }
            };
 
         // ����SequenceInputStream
        // ��ʹ��BufferedInputStream
        BufferedInputStream bufInputStream = 
            new BufferedInputStream( 
                    new SequenceInputStream(enumation), 
                    8192); 

        BufferedOutputStream bufOutputStream = 
                    new BufferedOutputStream( 
                       new FileOutputStream(filename), 8192); 

        byte[] data = new byte[1]; 
        // ��ȡ�����ļ����ݲ�д��Ŀ�ĵ��ļ�
        while(bufInputStream.read(data) != -1) 
            bufOutputStream.write(data); 

        bufInputStream.close(); 
        bufOutputStream.flush(); 
        bufOutputStream.close(); 
        System.out.println("���" + number + "���ļ� OK!!"); 
    } 
}