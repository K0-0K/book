package onlyfun.caterpillar;
 
import java.io.*;
import java.util.*;
 
public class CharArrayReaderWriterDemo {
    public static void main(String[] args) {
        try { 
            File file = new File(args[0]); 
            BufferedReader bufInputReader = 
                new BufferedReader( 
                     new FileReader(file)); 
 
            // ���ļ������ַ����� 
            CharArrayWriter charArrayWriter = 
                new CharArrayWriter(); 
            char[] array = new char[1]; 
            while(bufInputReader.read(array) != -1) {
                charArrayWriter.write(array); 
            }
             
            charArrayWriter.close(); 
            bufInputReader.close(); 
 
            // ��ʾ�ַ��������� 
            array = charArrayWriter.toCharArray(); 
            for(int i = 0; i < array.length; i++) 
                System.out.print(array[i] + " "); 
            System.out.println(); 
 
          // ��ʹ��������λ�����ַ��޸��ַ���������
            Scanner scanner = new Scanner(System.in);
             
            System.out.print("�����޸�λ�ã�"); 
            int pos = scanner.nextInt(); 
            System.out.print("�����޸��ַ���"); 
            char ch = scanner.next().charAt(0); 
            array[pos-1] = ch; 
 
            // ���ַ��������ݴ���ļ� 
            CharArrayReader charArrayReader = 
                new CharArrayReader(array); 
            BufferedWriter bufWriter = 
                new BufferedWriter( 
                     new FileWriter(file)); 
            char[] tmp = new char[1]; 
            while(charArrayReader.read(tmp) != -1) {
                bufWriter.write(tmp); 
            }
            
            charArrayReader.close();
            bufWriter.flush(); 
            bufWriter.close(); 
        } 
        catch(ArrayIndexOutOfBoundsException e) { 
            System.out.println("û��ָ���ļ�");
        } 
        catch(IOException e) { 
            e.printStackTrace(); 
        } 
    }
}