package onlyfun.caterpillar;
 
import java.io.*;
import java.util.*;
 
public class ObjectStreamDemo {
    public static void main(String[] args) {
        User[] users = {new User("cater", 101),
                        new User("justin", 102)}; 
        // д�����ļ�
        writeObjectsToFile(users, args[0]);

        try {
            // ��ȡ�ļ�����
            users = readObjectsFromFile(args[0]);
            // ��ʾ���صĶ���

            for(User user : users) {
                System.out.printf("%s\t%d%n", user.getName(), user.getNumber());
            }
            System.out.println();
            
            users = new User[2];
            users[0] = new User("momor", 103);
            users[1] = new User("becky", 104);
            
           // �����¶������ļ�
            appendObjectsToFile(users, args[0]);
            
            // ��ȡ�ļ�����
            users = readObjectsFromFile(args[0]);
            // ��ʾ���صĶ���

            for(User user : users) {
                System.out.printf("%s\t%d%n", user.getName(), user.getNumber());
            }
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("û��ָ���ļ���");
        }
        catch(FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    //��ָ���Ķ���д����ָ�����ļ�
    public static void writeObjectsToFile(
                         Object[] objs, String filename) { 
        File file = new File(filename);
 
        try { 
            ObjectOutputStream objOutputStream = 
                new ObjectOutputStream(
                      new FileOutputStream(file)); 
            for(Object obj : objs) {
                // ������д���ļ�
                objOutputStream.writeObject(obj); 
            }
            // �ر���

            objOutputStream.close(); 
        } 
        catch(IOException e) { 
            e.printStackTrace(); 
        }
    }
    
     // ��ָ���ļ��еĶ������ݶ���
    public static User[] readObjectsFromFile(
                             String filename) 
                               throws FileNotFoundException {
        File file = new File(filename); 
 
        // ����ļ������ھͶ����쳣
        if(!file.exists()) 
            throw new FileNotFoundException(); 
 
        // ʹ��List�ȴ洢���صĶ���

        List<User> list = new ArrayList<User>();
        
        try {
            FileInputStream fileInputStream = 
                new FileInputStream(file);
            ObjectInputStream objInputStream = 
                new ObjectInputStream(fileInputStream); 
            
            while(fileInputStream.available() > 0) {
                list.add((User) objInputStream.readObject());
            }
            objInputStream.close(); 
        } 
        catch(ClassNotFoundException e) { 
            e.printStackTrace(); 
        } 
        catch(IOException e) { 
            e.printStackTrace(); 
        }
 
        User[] users = new User[list.size()];
        return list.toArray(users);
    }
 
    // �����󸽼���ָ�����ļ�֮��
    public static void appendObjectsToFile(
                           Object[] objs, String filename) 
                               throws FileNotFoundException {
  
        File file = new File(filename); 
 
        // ����ļ��������򶪳��쳣
        if(!file.exists()) 
             throw new FileNotFoundException(); 

        try {
             // ����ģʽ
            ObjectOutputStream objOutputStream = 
               new ObjectOutputStream(
                  new FileOutputStream(file, true)) { 
                    // ���Ҫ���Ӷ������ļ���
                    // �������¶����������
                    protected void writeStreamHeader() 
                                     throws IOException {} 
               };  
 
            for(Object obj : objs) {
                // ������д���ļ�

                objOutputStream.writeObject(obj); 
            }
            objOutputStream.close(); 
        } 
        catch(IOException e) { 
            e.printStackTrace(); 
        } 
    }
}