package onlyfun.caterpillar;
 
import java.io.*; 
 
public class PushbackStreamDemo {
    public static void main(String[] args) {
        try { 
            PushbackInputStream pushbackInputStream = 
                new PushbackInputStream( 
                         new FileInputStream(args[0])); 
            byte[] array = new byte[2]; 
            int tmp = 0; 
            int count = 0; 

            while((count = pushbackInputStream.read(array))
                                             != -1) {
               // �����ֽ�ת��Ϊ���� 
                tmp = (short)((array[0] << 8) | 
                      (array[1] & 0xff)); 
                tmp = tmp & 0xFFFF; 
 
                 // �ж��Ƿ�ΪBIG5�����������ʾBIG5������
                if(tmp >= 0xA440 && tmp < 0xFFFF) {
                    System.out.println("BIG5: " + 
                             new String(array));
                } 
                else { 
                   // ���ڶ����ֽ��ƻ��� 
                    pushbackInputStream.unread(array, 1, 1); 
                    // ��ʾASCII��Χ���ַ�
                    System.out.println("ASCII: " + 
                            (char)array[0]); 
                } 
            } 
 
            pushbackInputStream.close(); 
        } 
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("��ָ���ļ�����");
        }
        catch(IOException e) { 
            e.printStackTrace(); 
        } 
    }
}