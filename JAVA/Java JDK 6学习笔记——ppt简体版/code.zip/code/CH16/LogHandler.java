

import java.util.logging.*; 
import java.lang.reflect.*; 

public class LogHandler implements InvocationHandler { 
    private Logger logger = 
               Logger.getLogger(this.getClass().getName()); 
    private Object delegate; 

    // ��Ҫ�����Ķ���
    public Object bind(Object delegate) { 
        this.delegate = delegate;
        // ���������ش�������
        return Proxy.newProxyInstance(
                 delegate.getClass().getClassLoader(),
                 // Ҫ�������Ľӿ�
                 delegate.getClass().getInterfaces(), 
                 this); 
    }

    // ����Ҫ���õķ�����������ǰ��������Ϊ
    public Object invoke(Object proxy, 
                         Method method, 
                         Object[] args) throws Throwable {
        Object result = null; 
        try { 
            logger.log(Level.INFO, 
                         "method starts..." + method.getName()); 
            result = method.invoke(delegate, args); 
            logger.log(Level.INFO, 
                         "method ends..." + method.getName()); 
        } catch (Exception e){ 
            logger.log(Level.INFO, e.toString()); 
        } 
        return result; 
    } 
}
