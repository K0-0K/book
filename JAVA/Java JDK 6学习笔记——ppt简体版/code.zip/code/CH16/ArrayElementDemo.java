

public class ArrayElementDemo {
    public static void main(String[] args) {
        short[] sArr = new short[5];
        int[] iArr = new int[5];
        long[] lArr = new long[5];
        float[] fArr = new float[5];
        double[] dArr = new double[5];
        byte[] bArr = new byte[5];
        boolean[] zArr = new boolean[5];
        String[] strArr = new String[5];

        System.out.println("short �����ࣺ" + sArr.getClass());
        System.out.println("int �����ࣺ" + iArr.getClass());
        System.out.println("long �����ࣺ" + lArr.getClass());
        System.out.println("float �����ࣺ" + fArr.getClass());
        System.out.println("double �����ࣺ" + dArr.getClass());
        System.out.println("byte �����ࣺ" + bArr.getClass());
        System.out.println("boolean �����ࣺ" + zArr.getClass());
        System.out.println("String �����ࣺ" + strArr.getClass());
    }
}