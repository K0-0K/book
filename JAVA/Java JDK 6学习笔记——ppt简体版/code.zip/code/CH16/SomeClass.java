

public class SomeClass {
    public static void main(String[] args) {
        // ����SomeClassʵ��
        SomeClass some = new SomeClass();
        // ȡ��SomeClass��Classʵ��
        Class c = some.getClass();
        // ȡ��ClassLoader
        ClassLoader loader = c.getClassLoader();
        System.out.println(loader);
        // ȡ�ø�ClassLoader
        System.out.println(loader.getParent());
        // ��ȡ�ø�ClassLoader
        System.out.println(loader.getParent().getParent());
    }
} 
