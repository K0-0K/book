

public interface IHello {
    public void hello(String name);
}