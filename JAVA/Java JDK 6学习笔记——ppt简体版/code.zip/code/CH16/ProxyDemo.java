

public class ProxyDemo {
    public static void main(String[] args) {
        LogHandler handler  = new LogHandler(); 
        IHello speaker = new HelloSpeaker();

        // ����speaker�Ķ���
        IHello speakerProxy = 
                 (IHello) handler.bind(speaker);

        speakerProxy.hello("Justin");        
    }
}
