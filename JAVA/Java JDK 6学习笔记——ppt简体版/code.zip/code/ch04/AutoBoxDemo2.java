public class AutoBoxDemo2 {
    public static void main(String[] args) {
        Integer i1 = 100;
        Integer i2 = 100;
 
        if (i1 == i2) 
            System.out.println("i1 == i2");
        else 
            System.out.println("i1 != i2");
    }
}