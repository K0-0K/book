public class AutoBoxDemo {
    public static void main(String[] args) {
        Integer data1 = 10;
        Integer data2 = 20;
        
       // תΪdoubleֵ�ٳ���3
        System.out.println(data1.doubleValue() / 3);

         // ��������ֵ�ıȽ�
        System.out.println(data1.compareTo(data2));
    }
}