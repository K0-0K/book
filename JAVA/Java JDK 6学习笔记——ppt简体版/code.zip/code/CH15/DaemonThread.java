package onlyfun.caterpillar;
 
public class DaemonThread { 
    public static void main(String[] args) {

        Thread thread = new Thread(
        // �����������д��
            new Runnable() {
                public void run() { 
                    while(true) { 
                        System.out.print("T"); 
                    } 
                }        
            }); 
        // �趨ΪDaemon�߳�
        thread.setDaemon(true); 
        thread.start(); 
    }
}