package com.shaccp.logic;

public interface IWeiboActivity {

	public void init();

	public void refresh(Object... args);

}
